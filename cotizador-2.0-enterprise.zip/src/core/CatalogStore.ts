import { create } from 'zustand';
import { TenantId } from './tenant';

export interface Space {
  id: string;
  name: string;
  category: string;
  capacity: number | string;
  status: string;
  tenantId: TenantId | 'all';
}

interface CatalogState {
  spaces: Space[];
}

export const useCatalogStore = create<CatalogState>(() => ({
  spaces: [
    { id: 'ESP-001', name: 'Salón Principal', category: 'Salones', capacity: 500, status: 'AVAILABLE', tenantId: 'plaza_mayor' },
    { id: 'ESP-002', name: 'Jardín Sur', category: 'Jardines', capacity: 200, status: 'MAINTENANCE', tenantId: 'plaza_mayor' },
    { id: 'ESP-003', name: 'Mupi 1 - Entrada', category: 'Publicidad Fija', capacity: '-', status: 'CONTRACTED', tenantId: 'plaza_mayor' },
    { id: 'ESP-CP-001', name: 'Salón Diamante', category: 'Salones', capacity: 300, status: 'AVAILABLE', tenantId: 'casa_de_piedra' },
    { id: 'ESP-CP-002', name: 'Jardín de los Olivos', category: 'Jardines', capacity: 150, status: 'AVAILABLE', tenantId: 'casa_de_piedra' },
  ]
}));
