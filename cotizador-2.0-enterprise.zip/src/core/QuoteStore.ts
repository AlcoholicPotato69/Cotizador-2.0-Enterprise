import { create } from 'zustand';

interface QuoteState {
  clientId: string | null;
  spaceId: string | null;
  services: string[];
  totalCalculation: any;
  setClient: (id: string) => void;
  setSpace: (id: string) => void;
  toggleService: (service: string) => void;
  calculateTotal: () => Promise<void>;
  reset: () => void;
}

export const useQuoteStore = create<QuoteState>((set, get) => ({
  clientId: null,
  spaceId: null,
  services: [],
  totalCalculation: null,
  setClient: (id) => set({ clientId: id }),
  setSpace: (id) => set({ spaceId: id }),
  toggleService: (service) => {
    const current = get().services;
    if (current.includes(service)) {
      set({ services: current.filter(s => s !== service) });
    } else {
      set({ services: [...current, service] });
    }
  },
  calculateTotal: async () => {
    // MOCK Backend calculation
    return new Promise(resolve => {
      setTimeout(() => {
        const basePrice = get().spaceId ? 15000 : 0;
        const servicesPrice = get().services.length * 2500;
        const subtotal = basePrice + servicesPrice;
        const tax = subtotal * 0.16;
        set({ totalCalculation: { subtotal, tax, total: subtotal + tax } });
        resolve();
      }, 1000);
    });
  },
  reset: () => set({ clientId: null, spaceId: null, services: [], totalCalculation: null }),
}));
