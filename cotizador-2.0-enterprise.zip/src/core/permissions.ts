import { create } from 'zustand';

export type Permission = 
  | 'view_dashboard' | 'view_command_center'
  | 'view_crm' | 'view_agenda' | 'view_catalog' 
  | 'view_contracts' | 'view_agreements' | 'view_vault' | 'view_finance'
  | 'view_tasks' | 'view_workflow' | 'view_reviews' | 'view_legal' | 'view_regulations'
  | 'view_reports' | 'view_audit' | 'view_archive' | 'view_activity' | 'view_snapshots'
  | 'view_operations' | 'view_storage' | 'view_tenants' | 'view_feature_flags' 
  | 'view_numbering' | 'view_observability' | 'view_settings'
  | 'manage_settings' | 'manage_users' | 'manage_roles'
  // Action Permissions (Global or Shared)
  | 'create' | 'read' | 'update' | 'delete' | 'archive' | 'restore'
  | 'approve' | 'reject' | 'sign' | 'download' | 'upload' | 'share' 
  | 'export' | 'import' | 'generate_pdf' | 'generate_invoice' 
  | 'generate_contract' | 'generate_agreement' | 'generate_receipt'
  // Domain Specific Actions
  | 'view_quotes' | 'create_quotes' | 'edit_quotes' | 'delete_quotes';

interface PermissionState {
  permissions: Permission[];
  setPermissions: (perms: Permission[]) => void;
  hasPermission: (perm: Permission | Permission[]) => boolean;
  hasAnyPermission: (perms: Permission[]) => boolean;
}

export const usePermissionStore = create<PermissionState>()((set, get) => ({
  permissions: [
    'view_dashboard', 'view_command_center', 'view_crm', 'view_agenda', 
    'view_catalog', 'view_quotes', 'view_contracts', 'view_agreements', 
    'view_vault', 'view_finance', 'view_tasks', 'view_workflow', 
    'view_reviews', 'view_legal', 'view_regulations', 'view_reports', 
    'view_audit', 'view_archive', 'view_activity', 'view_snapshots',
    'view_operations', 'view_storage', 'view_tenants', 'view_feature_flags',
    'view_numbering', 'view_observability', 'view_settings',
    'manage_settings', 'manage_users', 'manage_roles',
    'create', 'read', 'update', 'delete', 'archive', 'restore',
    'approve', 'reject', 'sign', 'download', 'upload', 'share',
    'export', 'import', 'generate_pdf', 'generate_invoice',
    'generate_contract', 'generate_agreement', 'generate_receipt'
  ], // Super admin defaults for demonstration
  setPermissions: (permissions) => set({ permissions }),
  hasPermission: (perm) => {
    const { permissions } = get();
    if (Array.isArray(perm)) {
      return perm.every(p => permissions.includes(p));
    }
    return permissions.includes(perm);
  },
  hasAnyPermission: (perms) => {
    const { permissions } = get();
    return perms.some(p => permissions.includes(p));
  }
}));
