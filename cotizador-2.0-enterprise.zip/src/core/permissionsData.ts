export interface PermissionMetadata {
  id: string;
  name: string;
  description: string;
  category: string;
}

export const PERMISSIONS_METADATA: PermissionMetadata[] = [
  // Dashboard & Views
  { id: 'view_dashboard', name: 'Ver Dashboard', description: 'Acceso a la vista principal', category: 'Navegación' },
  { id: 'view_command_center', name: 'Centro de Comando', description: 'Acceso al mapa interactivo y métricas globales', category: 'Navegación' },
  { id: 'view_crm', name: 'CRM y Clientes', description: 'Visualizar directorio de clientes y prospectos', category: 'Navegación' },
  { id: 'view_agenda', name: 'Agenda', description: 'Ver calendario y eventos programados', category: 'Navegación' },
  { id: 'view_catalog', name: 'Catálogo de Espacios', description: 'Ver salones, jardines y tarifas', category: 'Navegación' },
  { id: 'view_quotes', name: 'Ver Cotizaciones', description: 'Ver listado de cotizaciones', category: 'Navegación' },
  { id: 'view_contracts', name: 'Contratos', description: 'Ver contratos comerciales', category: 'Navegación' },
  { id: 'view_agreements', name: 'Convenios', description: 'Ver convenios especiales o corporativos', category: 'Navegación' },
  { id: 'view_vault', name: 'Bóveda de Documentos', description: 'Acceder a expedientes y documentos', category: 'Navegación' },
  { id: 'view_finance', name: 'Finanzas', description: 'Ver ingresos, facturas y pagos', category: 'Navegación' },
  { id: 'view_tasks', name: 'Ver Tareas', description: 'Acceso al módulo de tareas', category: 'Navegación' },
  { id: 'view_workflow', name: 'Workflows', description: 'Ver automatizaciones y flujos', category: 'Navegación' },
  { id: 'view_reviews', name: 'Aprobaciones', description: 'Ver bandeja de aprobaciones pendientes', category: 'Navegación' },
  { id: 'view_legal', name: 'Asuntos Legales', description: 'Ver litigios y seguimiento legal', category: 'Navegación' },
  { id: 'view_regulations', name: 'Reglamentos', description: 'Ver reglamentos operativos', category: 'Navegación' },
  { id: 'view_reports', name: 'Reportes', description: 'Generar y ver reportes del sistema', category: 'Navegación' },
  { id: 'view_audit', name: 'Auditoría', description: 'Ver logs y auditoría del sistema', category: 'Navegación' },
  { id: 'view_archive', name: 'Archivo Muerto', description: 'Aceso a documentos y eventos pasados', category: 'Navegación' },
  { id: 'view_activity', name: 'Actividad Reciente', description: 'Ver el desglose de interacciones', category: 'Navegación' },
  { id: 'view_snapshots', name: 'Snapshots', description: 'Ver el versionado de documentos', category: 'Navegación' },
  { id: 'view_operations', name: 'Operaciones', description: 'Ver módulo logístico y checklist', category: 'Navegación' },
  { id: 'view_storage', name: 'Almacenamiento Global', description: 'Ver reportes de almacenamiento de la nube', category: 'Configuración' },
  { id: 'view_tenants', name: 'Gestión de Tenants', description: 'Ver espacios y unidades de negocio', category: 'Configuración' },
  { id: 'view_feature_flags', name: 'Feature Flags', description: 'Ver módulos encendidos/apagados', category: 'Configuración' },
  { id: 'view_numbering', name: 'Folios y Numeración', description: 'Ver configuraciones de foliatura de documentos', category: 'Configuración' },
  { id: 'view_observability', name: 'Observabilidad', description: 'Ver telemetría y salud del sistema', category: 'Configuración' },
  { id: 'view_settings', name: 'Configuración Básica', description: 'Aceso a la vista de settings', category: 'Configuración' },

  // Administrative Actions
  { id: 'manage_settings', name: 'Gestionar Configuración', description: 'Cambiar colores, metadatos y preferencias', category: 'Administración' },
  { id: 'manage_users', name: 'Gestionar Usuarios', description: 'Crear, editar o desactivar usuarios', category: 'Administración' },
  { id: 'manage_roles', name: 'Gestionar Roles', description: 'Interfase de matriz de roles (RBAC)', category: 'Administración' },

  // General Actions
  { id: 'create', name: 'Crear', description: 'Crear nuevos elementos de forma genérica', category: 'Acciones Generales' },
  { id: 'read', name: 'Leer', description: 'Leer el contenido a detalle', category: 'Acciones Generales' },
  { id: 'update', name: 'Actualizar', description: 'Actualizar elementos existentes', category: 'Acciones Generales' },
  { id: 'delete', name: 'Eliminar', description: 'Eliminar de la base de datos de manera lógica', category: 'Acciones Generales' },
  { id: 'archive', name: 'Archivar', description: 'Mandar al módulo de archivado global', category: 'Acciones Generales' },
  { id: 'restore', name: 'Restaurar', description: 'Restaurar registros del archivo', category: 'Acciones Generales' },
  { id: 'approve', name: 'Aprobar', description: 'Dar el VoBo positivo a workflows o documentos', category: 'Acciones Generales' },
  { id: 'reject', name: 'Rechazar', description: 'Rechazar requerimientos o documentos', category: 'Acciones Generales' },
  { id: 'sign', name: 'Firmar', description: 'Firma digital de documentos', category: 'Acciones Generales' },
  { id: 'download', name: 'Descargar', description: 'Descargar archivos adjuntos o PDFs', category: 'Acciones Generales' },
  { id: 'upload', name: 'Subir', description: 'Carga de archivos locales al sistema', category: 'Acciones Generales' },
  { id: 'share', name: 'Compartir', description: 'Generar links públicos de lectura', category: 'Acciones Generales' },
  { id: 'export', name: 'Exportar a CSV/Excel', description: 'Extraer data-tables e informes', category: 'Acciones Generales' },
  { id: 'import', name: 'Importar', description: 'Importar datos masivamente', category: 'Acciones Generales' },
  { id: 'generate_pdf', name: 'Generar PDF', description: 'Ejecución del motor generativo DocGenerative para un PDF', category: 'Acciones Generales' },
  { id: 'generate_invoice', name: 'Generar Factura', description: 'Timbrado de recibo CFDI (Mockup)', category: 'Acciones Generales' },
  { id: 'generate_contract', name: 'Generar Contrato', description: 'Compilar plantilla y variables en formato PDF', category: 'Acciones Generales' },
  { id: 'generate_agreement', name: 'Generar Convenio', description: 'Crear documentos B2B de convenios', category: 'Acciones Generales' },
  { id: 'generate_receipt', name: 'Generar Recibo', description: 'Generación de recibo de flujo en caja local', category: 'Acciones Generales' },

  // Domain Specific Actions
  { id: 'create_quotes', name: 'Crear Cotizaciones', description: 'Guardar preliminares en inventario', category: 'Cotizaciones' },
  { id: 'edit_quotes', name: 'Editar Cotizaciones', description: 'Redactar descuentos o ajustes en cotizaciones vigentes', category: 'Cotizaciones' },
  { id: 'delete_quotes', name: 'Eliminar Cotizaciones', description: 'Cancelar o remover cotizaciones en stand-by', category: 'Cotizaciones' },
];

export const getPermissionsByCategory = () => {
  const grouped = PERMISSIONS_METADATA.reduce((acc, curr) => {
    if (!acc[curr.category]) acc[curr.category] = [];
    acc[curr.category].push(curr);
    return acc;
  }, {} as Record<string, PermissionMetadata[]>);

  return Object.entries(grouped).map(([name, permissions]) => ({ name, permissions }));
};
