import React, { useState } from 'react';
import { BaseCard } from '../../components/base/BaseCard';
import { BaseBreadcrumb } from '../../components/base/BaseBreadcrumb';
import { BaseButton } from '../../components/base/BaseButton';
import { BaseModal } from '../../components/base/BaseModal';
import { BaseSelect } from '../../components/base/BaseSelect';
import { PermissionGuard } from '../../core/PermissionGuard';
import { Plus } from 'lucide-react';
import { BaseDataTable } from '../../components/base/BaseDataTable';
import { toast } from 'sonner';

export function ContractsList() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleCreate = () => {
    toast.success('Borrador de contrato creado exitosamente');
    setIsModalOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <BaseBreadcrumb items={[{ label: 'Contratos' }]} className="mb-6" />
      <div className="flex justify-between items-end mb-6">
        <div>
          <h1 className="text-2xl font-bold text-text-primary tracking-tight">Centro de Contratos</h1>
          <p className="text-sm text-text-secondary mt-1">Gestión del ciclo de vida de contratos.</p>
        </div>
        <PermissionGuard permissions="update">
          <BaseButton onClick={() => setIsModalOpen(true)}>
            <Plus className="w-5 h-5 mr-2" />
            Crear Contrato
          </BaseButton>
        </PermissionGuard>
      </div>
      <BaseCard noPadding>
        <BaseDataTable columns={[{ key: 'id', label: 'ID' }, { key: 'client', label: 'Cliente' }, { key: 'status', label: 'Estado' }]} data={[]} />
      </BaseCard>

      <BaseModal
        title="Crear Nuevo Contrato"
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      >
        <div className="space-y-4">
          <div className="p-3 bg-brand-primary/10 rounded-lg text-sm text-brand-primary">
            Normalmente, los contratos se generan automáticamente al aprobar una cotización. Utiliza esta opción solo para contratos manuales.
          </div>
          <BaseSelect 
            label="Cliente" 
            options={[
              { value: 'Acme Corp', label: 'Acme Corp' },
              { value: 'TechFlow', label: 'TechFlow' }
            ]} 
          />
          <BaseSelect 
            label="Plantilla de Contrato" 
            options={[
              { value: 'arrendamiento', label: 'Arrendamiento de Espacio P.M.' },
              { value: 'publicidad', label: 'Contrato Mupis 2026' }
            ]} 
          />
          <div className="flex justify-end gap-3 mt-6">
            <BaseButton variant="ghost" onClick={() => setIsModalOpen(false)}>Cancelar</BaseButton>
            <BaseButton variant="primary" onClick={handleCreate}>Generar Contrato</BaseButton>
          </div>
        </div>
      </BaseModal>
    </div>
  );
}
