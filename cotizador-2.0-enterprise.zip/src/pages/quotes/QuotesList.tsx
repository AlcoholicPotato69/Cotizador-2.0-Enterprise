import { BaseDataTable } from '../../components/base/BaseDataTable';
import { BaseInput } from '../../components/base/BaseInput';
import { BaseButton } from '../../components/base/BaseButton';
import { BaseModal } from '../../components/base/BaseModal';
import { BaseSelect } from '../../components/base/BaseSelect';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { WorkflowBadge } from '../../components/workflow/WorkflowBadge';
import { PermissionGuard } from '../../core/PermissionGuard';
import { Plus, Search, Filter } from 'lucide-react';
import { toast } from 'sonner';

export function QuotesList() {
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const dummyData = [
    { id: 'COT-001', client: 'Acme Corp', total: '$14,500.00', status: 'DRAFT', date: '24 May 2026' },
    { id: 'COT-002', client: 'TechFlow', total: '$8,200.00', status: 'SENT', date: '20 May 2026' },
    { id: 'COT-003', client: 'Global Industries', total: '$32,100.00', status: 'APPROVED', date: '15 May 2026' },
  ];

  const columns = [
    { header: 'ID', accessorKey: 'id' },
    { header: 'Cliente', accessorKey: 'client' },
    { header: 'Total', accessorKey: 'total' },
    { header: 'Fecha', accessorKey: 'date' },
    { 
      header: 'Estado', 
      accessorKey: 'status',
      cell: (row: any) => <WorkflowBadge state={row.status} />
    },
  ];

  const handleCreate = () => {
    setIsModalOpen(false);
    navigate('/app/quotes/new');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-text-primary tracking-tight">Cotizaciones</h1>
          <p className="text-text-secondary mt-1">Gestión de cotizaciones y propuestas comerciales.</p>
        </div>
        <PermissionGuard permissions="create_quotes">
          <BaseButton onClick={() => setIsModalOpen(true)}>
            <Plus className="w-5 h-5 mr-2" />
            Nueva Cotización
          </BaseButton>
        </PermissionGuard>
      </div>

      <div className="bg-bg-surface border border-border-base rounded-xl p-4 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 md:max-w-md relative">
            <BaseInput 
              placeholder="Buscar por ID, cliente..." 
              className="pl-10"
            />
            <Search className="w-4 h-4 text-text-tertiary absolute left-3 top-3" />
          </div>
          <BaseButton variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filtros
          </BaseButton>
        </div>
        
        <BaseDataTable 
          data={dummyData} 
          columns={columns} 
          onRowClick={(row) => navigate(`/app/quotes/${row.id}`)}
        />
      </div>

      <BaseModal
        title="Crear Nueva Cotización"
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      >
        <div className="space-y-4">
          <BaseSelect 
            label="Cliente" 
            options={[
              { value: 'Acme Corp', label: 'Acme Corp' },
              { value: 'TechFlow', label: 'TechFlow' },
              { value: 'Global Industries', label: 'Global Industries' }
            ]} 
          />
          <BaseSelect 
            label="Tipo de Espacio" 
            options={[
              { value: 'Salón', label: 'Salón' },
              { value: 'Publicidad Digital', label: 'Publicidad Digital' }
            ]} 
          />
          <div className="flex justify-end gap-3 mt-6">
            <BaseButton variant="ghost" onClick={() => setIsModalOpen(false)}>Cancelar</BaseButton>
            <BaseButton variant="primary" onClick={handleCreate}>Crear Cotización</BaseButton>
          </div>
        </div>
      </BaseModal>
    </div>
  );
}
