import { BaseCard } from '../../components/base/BaseCard';
import { BaseButton } from '../../components/base/BaseButton';
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, FileText, CheckCircle, Download, FileSignature } from 'lucide-react';
import { WorkflowBadge } from '../../components/workflow/WorkflowBadge';
import { PermissionGuard } from '../../core/PermissionGuard';
import { QuoteCreationWizard } from './QuoteCreationWizard';
import { toast } from 'sonner';

export function QuoteDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [isDownloading, setIsDownloading] = useState(false);
  const [isApproving, setIsApproving] = useState(false);

  if (id === 'new') {
    return <QuoteCreationWizard />;
  }

  const handleDownload = () => {
    setIsDownloading(true);
    toast.promise(
      new Promise(resolve => setTimeout(resolve, 1500)),
      {
        loading: 'Generando PDF de cotización...',
        success: () => {
          setIsDownloading(false);
          return 'Cotización descargada correctamente.';
        },
        error: () => {
          setIsDownloading(false);
          return 'Error en la descarga.';
        }
      }
    );
  };

  const handleApprove = () => {
    setIsApproving(true);
    toast.success('Cotización aprobada. Generando contrato...');
    setTimeout(() => {
      setIsApproving(false);
      navigate('/app/contracts');
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => navigate('/app/quotes')}
            className="p-2 hover:bg-bg-surface-hover rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-text-secondary" />
          </button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold text-text-primary tracking-tight">Cotización {id}</h1>
              <WorkflowBadge state="SENT" />
            </div>
            <p className="text-text-secondary mt-1">Acme Corp • 24 May 2026</p>
          </div>
        </div>
        <div className="flex gap-2">
          <PermissionGuard permissions="download">
            <BaseButton variant="outline" onClick={handleDownload} isLoading={isDownloading}>
              <Download className="w-4 h-4 mr-2" />
              Descargar
            </BaseButton>
          </PermissionGuard>
          <PermissionGuard permissions="approve">
            <BaseButton onClick={handleApprove} isLoading={isApproving}>
              <CheckCircle className="w-4 h-4 mr-2" />
              Aprobar y Generar Contrato
            </BaseButton>
          </PermissionGuard>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-bg-surface border border-border-base rounded-xl p-6">
            <h2 className="text-lg font-semibold text-text-primary mb-4">Desglose de Precios</h2>
            <div className="space-y-4">
              {/* Desglose de precios here */}
              <div className="flex justify-between items-center py-3 border-b border-border-base">
                <div>
                  <p className="font-medium text-text-primary">Salón Principal</p>
                  <p className="text-sm text-text-secondary">Arrendamiento 15 Jun - 16 Jun 2026</p>
                </div>
                <p className="font-medium text-text-primary">$12,000.00 MXN</p>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-border-base">
                <div>
                  <p className="font-medium text-text-primary">Servicio de Catering</p>
                  <p className="text-sm text-text-secondary">Paquete Premium 500 personas</p>
                </div>
                <p className="font-medium text-text-primary">$2,500.00 MXN</p>
              </div>
              <div className="pt-4 flex justify-end">
                <div className="w-64 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-text-secondary">Subtotal</span>
                    <span className="text-text-primary font-medium">$14,500.00 MXN</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-text-secondary">IVA (16%)</span>
                    <span className="text-text-primary font-medium">$2,320.00 MXN</span>
                  </div>
                  <div className="pt-2 border-t border-border-base flex justify-between text-lg font-bold">
                    <span className="text-text-primary">TOTAL</span>
                    <span className="text-brand-primary">$16,820.00 MXN</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-bg-surface border border-border-base rounded-xl p-6">
            <h2 className="text-lg font-semibold text-text-primary mb-4">Archivos Adjuntos (Quote Files)</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               <div 
                 onClick={() => navigate('/app/documents/DOC-001')}
                 className="flex items-center gap-3 p-3 border border-border-base rounded-lg hover:border-brand-primary cursor-pointer transition-colors"
               >
                  <div className="w-10 h-10 rounded bg-brand-primary/10 text-brand-primary flex items-center justify-center">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-text-primary">Propuesta_Acme_v1.pdf</p>
                    <p className="text-xs text-text-secondary">2.4 MB • 24 May 2026</p>
                  </div>
               </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <BaseCard title="Resumen" headerAction={<FileSignature className="w-5 h-5 text-text-tertiary" />}>
             <div className="space-y-4">
                <div>
                  <p className="text-sm text-text-secondary">Cliente</p>
                  <p className="font-medium text-text-primary">Acme Corp</p>
                </div>
                <div>
                  <p className="text-sm text-text-secondary">Válido hasta</p>
                  <p className="font-medium text-text-primary">24 Jun 2026</p>
                </div>
                <div>
                  <p className="text-sm text-text-secondary">Moneda</p>
                  <p className="font-medium text-text-primary">MXN</p>
                </div>
             </div>
          </BaseCard>
          
          <div className="bg-bg-surface border border-border-base rounded-xl p-6">
             <h3 className="text-sm font-semibold text-text-primary uppercase tracking-wider mb-4">Integración Workflow</h3>
             <ul className="space-y-4 relative before:absolute before:inset-y-0 before:left-2.5 before:w-px before:bg-border-base">
               <li className="relative flex gap-4">
                 <div className="w-5 h-5 rounded-full bg-brand-primary text-text-inverted flex items-center justify-center shrink-0 z-10">
                   <div className="w-2 h-2 rounded-full bg-white" />
                 </div>
                 <div>
                   <p className="text-sm font-medium text-text-primary">Borrador Creado</p>
                   <p className="text-xs text-text-secondary">23 May 2026 14:00</p>
                 </div>
               </li>
               <li className="relative flex gap-4">
                 <div className="w-5 h-5 rounded-full bg-brand-primary text-text-inverted flex items-center justify-center shrink-0 z-10">
                   <div className="w-2 h-2 rounded-full bg-white" />
                 </div>
                 <div>
                   <p className="text-sm font-medium text-text-primary">Enviado al Cliente</p>
                   <p className="text-xs text-text-secondary">24 May 2026 09:30</p>
                 </div>
               </li>
               <li className="relative flex gap-4">
                 <div className="w-5 h-5 rounded-full bg-bg-surface border-2 border-border-base flex items-center justify-center shrink-0 z-10" />
                 <div>
                   <p className="text-sm font-medium text-text-secondary">Aprobación del Cliente</p>
                   <p className="text-xs text-text-tertiary">Pendiente</p>
                 </div>
               </li>
             </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
