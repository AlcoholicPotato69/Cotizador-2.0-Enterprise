import { BaseStatsCard } from '../../components/base/BaseStatsCard';
import { BaseButton } from '../../components/base/BaseButton';
import React, { useState } from 'react';
import { BaseCard } from '../../components/base/BaseCard';
import { BaseModal } from '../../components/base/BaseModal';
import { useTenantStore } from '../../core/tenant';
import { Activity, Clock, AlertCircle, CheckCircle2, TrendingUp, Calendar, FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function Dashboard() {
  const { currentTenant, tenantMetadata } = useTenantStore();
  const tenant = currentTenant ? tenantMetadata[currentTenant] : null;
  const navigate = useNavigate();

  const [isActivityModalOpen, setIsActivityModalOpen] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState<any>(null);

  const handleViewDetails = (activity: any) => {
    setSelectedActivity(activity);
    setIsActivityModalOpen(true);
  };

  const handleNavigateToActivity = () => {
    setIsActivityModalOpen(false);
    if (selectedActivity?.type === 'QUOTE') {
      navigate('/app/quotes');
    } else {
      navigate('/app/contracts');
    }
  };

  const activities = [
    { id: 1, type: 'CONTRACT', description: 'Contrato firmado por Cliente XYZ', author: 'Sarah Jenkins', time: 'Hace 2 horas', status: 'COMPLETED' },
    { id: 2, type: 'QUOTE', description: 'Nueva cotización #COT-2026 generada', author: 'Michael Brown', time: 'Hace 4 horas', status: 'PENDING' },
    { id: 3, type: 'CONTRACT', description: 'Contrato firmado por Global Industries', author: 'Sarah Jenkins', time: 'Hace 6 horas', status: 'COMPLETED' },
    { id: 4, type: 'QUOTE', description: 'Nueva cotización #COT-2027 declinada', author: 'Emma Davis', time: 'Hace 8 horas', status: 'REJECTED' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-2xl font-bold text-text-primary tracking-tight">
          Hola, John
        </h1>
        <p className="text-text-secondary mt-1">
          Aquí tienes el resumen de hoy para <span className="font-semibold text-text-primary">{tenant?.name || 'la plataforma'}</span>.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <BaseStatsCard
          title="Cotizaciones Aprobadas"
          value="142"
          icon={<TrendingUp className="w-5 h-5" />}
          trend={{ value: "+12% vs mes anterior", isPositive: true }}
        />

        <BaseStatsCard
          title="Por Validar Firmas"
          value="18"
          icon={<Clock className="w-5 h-5 text-warning" />}
        />

        <BaseStatsCard
          title="Eventos Confirmados"
          value="5"
          icon={<Calendar className="w-5 h-5 text-brand-primary" />}
          trend={{ value: "Próximos 7 días", isPositive: true }}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-text-primary">Actividad Reciente</h2>
            <button className="text-sm font-medium text-brand-primary hover:text-brand-hover" onClick={() => navigate('/app/activity')}>Ver todo</button>
          </div>
          
          <BaseCard noPadding>
            <div className="divide-y divide-border-base">
              {activities.map((activity) => (
                <div key={activity.id} className="p-4 flex gap-4 hover:bg-bg-surface-hover transition-colors">
                  <div className="flex-shrink-0 mt-1">
                    {activity.type === 'CONTRACT' ? (
                      <CheckCircle2 className="w-5 h-5 text-success" />
                    ) : (
                      <FileText className="w-5 h-5 text-brand-primary" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-text-primary">
                      {activity.description}
                    </p>
                    <p className="text-xs text-text-secondary mt-1">{activity.time} • Por {activity.author}</p>
                  </div>
                  <div className="flex items-center">
                    <BaseButton variant="ghost" onClick={() => handleViewDetails(activity)}>Ver Detalles</BaseButton>
                  </div>
                </div>
              ))}
            </div>
          </BaseCard>
        </div>

        <div className="space-y-6">
          <h2 className="text-lg font-semibold text-text-primary">Alertas del Sistema</h2>
          <BaseCard noPadding>
            <div className="divide-y divide-border-base p-2">
              <div className="p-3 bg-danger/5 rounded-lg border border-danger/10 flex gap-3 mb-2">
                <AlertCircle className="w-5 h-5 text-danger flex-shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-danger">Cotización expirada</p>
                  <p className="text-xs text-danger/80 mt-1">COT-2025-099 ha excedido su tiempo límite.</p>
                </div>
              </div>
              <div className="p-3 bg-warning/5 rounded-lg border border-warning/10 flex gap-3">
                <Clock className="w-5 h-5 text-warning flex-shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-warning">Revisión mensual</p>
                  <p className="text-xs text-warning/80 mt-1">Faltan 2 días para el cierre de tenant Administrativo.</p>
                </div>
              </div>
            </div>
          </BaseCard>
        </div>
      </div>

      <BaseModal
        title="Detalles de la Actividad"
        isOpen={isActivityModalOpen}
        onClose={() => setIsActivityModalOpen(false)}
      >
        <div className="space-y-4">
          <div className="bg-bg-base p-4 rounded-lg border border-border-base">
            <h3 className="text-sm font-semibold text-text-primary mb-2">Resumen</h3>
            <p className="text-text-secondary text-sm">{selectedActivity?.description}</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
             <div>
               <p className="text-xs text-text-tertiary uppercase tracking-wider mb-1">Autor</p>
               <p className="text-sm font-medium text-text-primary">{selectedActivity?.author}</p>
             </div>
             <div>
               <p className="text-xs text-text-tertiary uppercase tracking-wider mb-1">Timestamp</p>
               <p className="text-sm font-medium text-text-primary">{selectedActivity?.time}</p>
             </div>
          </div>
          <div className="flex justify-end gap-3 mt-6">
            <BaseButton variant="ghost" onClick={() => setIsActivityModalOpen(false)}>Cerrar</BaseButton>
            <BaseButton variant="primary" onClick={handleNavigateToActivity}>Ir al Documento</BaseButton>
          </div>
        </div>
      </BaseModal>
    </div>
  );
}
