import { BaseAvatar } from '../base/BaseAvatar';
import { BaseButton } from '../base/BaseButton';
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BaseDossierViewer, DossierSection, DossierField } from './BaseDossierViewer';
import { FileText } from 'lucide-react';

interface ClientDossierProps {
  client?: any;
}

export function ClientDossier({ client }: ClientDossierProps) {
  const navigate = useNavigate();

  const header = (
    <div className="flex items-center gap-4">
      <BaseAvatar size="lg" initials={client?.name || 'C'} />
      <div>
        <h2 className="text-lg font-bold text-text-primary">{client?.name || 'Nombre del Cliente'}</h2>
        <p className="text-sm text-text-secondary">{client?.legalName || 'Razón social'}</p>
      </div>
    </div>
  );

  return (
    <BaseDossierViewer header={header}>
      <DossierSection title="Información General">
        <DossierField label="ID Cliente" value={client?.id || 'CLI-0000'} />
        <DossierField label="RFC" value={client?.rfc || 'XAXX010101000'} />
        <DossierField label="Estado" value={client?.status || 'Activo'} isBadge />
      </DossierSection>
      <DossierSection title="Contacto Principal">
        <DossierField label="Nombre" value={client?.contactName || 'No especificado'} />
        <DossierField label="Email" value={client?.contactEmail || 'No especificado'} />
        <DossierField label="Teléfono" value={client?.contactPhone || 'No especificado'} />
      </DossierSection>
      <DossierSection title="Expediente Mantenimiento">
        <div 
          onClick={() => navigate('/app/documents/DOC-001')}
          className="flex items-center gap-3 p-3 border border-border-base rounded-lg hover:border-brand-primary cursor-pointer transition-colors mt-2"
        >
          <div className="w-10 h-10 rounded bg-brand-primary/10 text-brand-primary flex items-center justify-center">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <p className="text-sm font-medium text-text-primary">Acta Constitutiva</p>
            <p className="text-xs text-text-secondary">Verificado • 10 Ene 2024</p>
          </div>
        </div>
        <div 
          onClick={() => navigate('/app/documents/DOC-002')}
          className="flex items-center gap-3 p-3 border border-border-base rounded-lg hover:border-brand-primary cursor-pointer transition-colors mt-2"
        >
          <div className="w-10 h-10 rounded bg-brand-primary/10 text-brand-primary flex items-center justify-center">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <p className="text-sm font-medium text-text-primary">Comprobante de Domicilio</p>
            <p className="text-xs text-text-secondary">Verificado • 10 Ene 2024</p>
          </div>
        </div>
      </DossierSection>
    </BaseDossierViewer>
  );
}
